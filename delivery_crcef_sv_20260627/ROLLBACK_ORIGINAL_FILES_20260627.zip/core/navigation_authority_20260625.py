"""Authoritative page navigation helper.


Keeps all mirrored state keys synchronized in one place and prevents programmatic

navigation clicks from being partially overwritten during the same rerun.
"""

from __future__ import annotations

from typing import Any, MutableMapping

import time, uuid


TX_KEY = "navigation_tx_20260625"


def navigate_to(state: MutableMapping[str, Any], page: str, subpage: str = "", lunch_field: str | None = None) -> dict[str, Any]:

    page = str(page or "Settings").strip() or "Settings"
    if page in {"Field 4 to 9", "Field 456+789", "Field 456", "Field 789"}:
        page = "Dinner"

    subpage = str(subpage or "").strip()

    tx = {

        "id": uuid.uuid4().hex[:16],

        "page": page,

        "subpage": subpage,

        "lunch_field": lunch_field,

        "timestamp": time.time(),

    }

    state[TX_KEY] = tx

    state["active_page"] = page

    state["tab_choice"] = page

    state["active_subpage"] = subpage

    state["ui_navigation_click_ts"] = tx["timestamp"]

    state["fast_tab_switch_active"] = True

    if page in {"Lunch", "Morning", "Research"}:

        state["home_inner_tab"] = page

    if page == "Lunch":

        state["lunch_active_subpage"] = subpage

    elif page == "Research":

        state["research_active_subpage"] = subpage

    elif page == "Dinner":

        state["dinner_active_subpage"] = subpage

    if lunch_field:

        state["lunch_active_field_selector_20260624"] = lunch_field

        state["lunch_active_field_selector_20260624__pending"] = lunch_field

    return tx


__all__ = ["navigate_to", "TX_KEY"]
