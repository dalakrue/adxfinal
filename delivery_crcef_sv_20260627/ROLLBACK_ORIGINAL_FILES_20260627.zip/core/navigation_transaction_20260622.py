"""One-use programmatic navigation transaction for Settings -> Lunch Field 1."""
from __future__ import annotations
from typing import Any, MutableMapping, Mapping
import hashlib, time

TOKEN_KEY = "pending_navigation_quant_v6_20260622"


def request_lunch_navigation(state: MutableMapping[str, Any], *, generation_id: Any, reason: str, used_previous: bool = False):
    signature = hashlib.sha256(f"Lunch|{generation_id}|{reason}|{int(used_previous)}".encode()).hexdigest()[:24]
    existing = state.get(TOKEN_KEY)
    if isinstance(existing, Mapping) and existing.get("signature") == signature and not existing.get("confirmed"):
        token = dict(existing)
    else:
        token = {"token": signature, "signature": signature, "target_page": "Lunch", "target_field": 1, "generation_id": str(generation_id or "UNAVAILABLE"), "request_timestamp": time.time(), "reason": str(reason), "used_previous": bool(used_previous), "consumed": False, "confirmed": False}
    state[TOKEN_KEY] = token
    state.update({"active_page": "Lunch", "tab_choice": "Lunch", "home_inner_tab": "Lunch", "active_subpage": "", "lunch_active_subpage": "", "lunch_field_open_1_20260621": True, "lunch_field_widget_1_20260621": True, "lunch_scroll_to_field1_20260621": True, "lunch_focus_current_result_20260622": True})
    state["settings_used_previous_canonical_20260622"] = bool(used_previous)
    return token


def pending_lunch_navigation(state: Mapping[str, Any]) -> bool:
    token = state.get(TOKEN_KEY)
    return isinstance(token, Mapping) and token.get("target_page") == "Lunch"


def consume_pending_navigation(state: MutableMapping[str, Any]):
    token = state.get(TOKEN_KEY)
    if not isinstance(token, Mapping) or token.get("target_page") != "Lunch": return None
    token = dict(token); token["consumed"] = True; token["consumed_timestamp"] = time.time(); state[TOKEN_KEY] = token
    state.update({"active_page": "Lunch", "tab_choice": "Lunch", "home_inner_tab": "Lunch", "active_subpage": "", "lunch_active_subpage": "", "lunch_field_open_1_20260621": True, "lunch_field_widget_1_20260621": True, "lunch_scroll_to_field1_20260621": True, "lunch_focus_current_result_20260622": True})
    return token


def confirm_lunch_navigation(state: MutableMapping[str, Any], page: str) -> bool:
    token = state.get(TOKEN_KEY)
    if not isinstance(token, Mapping) or str(page) != "Lunch": return False
    state.pop(TOKEN_KEY, None); state["lunch_calculation_completed_notice_20260621"] = True; state["lunch_auto_open_message_20260622"] = "Calculation completed — Lunch Field 1 opened automatically."; state["lunch_auto_open_used_previous_20260622"] = bool(token.get("used_previous")); return True
