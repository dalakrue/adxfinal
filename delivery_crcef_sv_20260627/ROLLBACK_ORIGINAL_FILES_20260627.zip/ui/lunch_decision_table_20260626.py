"""Field 1 Decision History — 25-day, read-only presentation table."""
from __future__ import annotations
from types import SimpleNamespace
from typing import Any, Mapping, MutableMapping
import pandas as pd
from core.decision_table_20260626 import build_decision_table, consensus_diagnostic

# Legacy static-test marker only: Table 1 of 3 — Decision History — Last 25 Days


def _snapshot(canonical: Mapping[str, Any]) -> Any:
    broker = canonical.get("broker_candle_time") or canonical.get("latest_completed_candle_time")
    created = canonical.get("created_at_utc") or canonical.get("created_at") or broker
    stamp = pd.to_datetime(broker, errors="coerce", utc=True)
    if pd.isna(stamp):
        raise ValueError("canonical completed broker candle is unavailable")
    made = pd.to_datetime(created, errors="coerce", utc=True)
    if pd.isna(made):
        made = stamp
    regime = canonical.get("regime") if isinstance(canonical.get("regime"), Mapping) else {}
    decision = canonical.get("final_decision") if isinstance(canonical.get("final_decision"), Mapping) else {}
    return SimpleNamespace(
        broker_candle_time=pd.Timestamp(stamp),
        created_at_utc=pd.Timestamp(made),
        run_id=str(canonical.get("run_id") or canonical.get("canonical_calculation_id") or "unknown"),
        generation_id=str(canonical.get("generation_id") or canonical.get("calculation_generation") or "unknown"),
        source_snapshot_hash=str(canonical.get("source_snapshot_hash") or canonical.get("snapshot_hash") or "unknown"),
        symbol=str(canonical.get("symbol") or "EURUSD"),
        timeframe=str(canonical.get("timeframe") or "H1"),
        decision=str(decision.get("final_decision") or canonical.get("full_metric_direction") or "WAIT"),
        regime=str(regime.get("major_regime") or regime.get("current_regime") or "UNKNOWN"),
    )


def _fallback_from_history(state: Mapping[str, Any]) -> pd.DataFrame:
    payload = state.get("one_hour_direction_confirmation_20260626")
    raw = payload.get("history") if isinstance(payload, Mapping) else None
    frame = raw.copy() if isinstance(raw, pd.DataFrame) else pd.DataFrame(raw or [])
    if not frame.empty:
        return frame
    # Table 1 is a read-only collection of Table 3 histories. It must remain
    # visible even when the canonical identity strip is temporarily unbound.
    for key in ("lunch_metric_result_cache", "full_metric_result_cache_20260618",
                "lunch_metric_result_published_20260618", "lunch_metric_result_20260619",
                "eurusd_h1_matrix_result", "eurusd_h1_matrix_export"):
        result = state.get(key)
        if not isinstance(result, Mapping):
            continue
        overall = result.get("history")
        if isinstance(overall, pd.DataFrame) and not overall.empty:
            return overall.copy()
        if isinstance(overall, list) and overall:
            return pd.DataFrame(overall)
        histories = result.get("history_by_factor")
        if isinstance(histories, Mapping) and histories:
            # Use the existing adapter with an identity-free display snapshot.
            times = []
            for value in histories.values():
                f = value if isinstance(value, pd.DataFrame) else pd.DataFrame(value or [])
                if f.empty: continue
                tc = next((c for c in ("Broker Candle Time","broker_candle_time","time","datetime","DateTime","date") if c in f.columns), None)
                if tc is not None:
                    t = pd.to_datetime(f[tc], errors="coerce", utc=True).dropna()
                    if len(t): times.append(t.max())
            if times:
                snap = SimpleNamespace(broker_candle_time=max(times), created_at_utc=max(times),
                    run_id="UNBOUND", generation_id="UNBOUND", source_snapshot_hash="UNBOUND",
                    symbol=str(state.get("symbol") or "EURUSD"), timeframe=str(state.get("timeframe") or "H1"),
                    decision="WAIT", regime="UNKNOWN")
                try:
                    return build_decision_table(state, snap)
                except Exception:
                    pass
    for key in ("full_metric_history_df_20260618", "full_metric_history_df", "decision_history_df"):
        frame = state.get(key)
        if isinstance(frame, pd.DataFrame) and not frame.empty:
            return frame.copy()
    return pd.DataFrame()


def render_field1_decision_history(*, state: MutableMapping[str, Any], canonical: Mapping[str, Any]) -> None:
    import streamlit as st
    st.markdown("#### Table 1 — Decision History — Last 25 Days")
    st.caption("Field 1 source of truth · decision columns only · newest completed broker candle first · no production decision is rewritten.")
    try:
        table = build_decision_table(state, _snapshot(canonical))
    except Exception:
        table = _fallback_from_history(state)
    if isinstance(table, pd.DataFrame) and not table.empty:
        from core.self_contained_table_logic_20260627 import enrich_decision_history
        table = enrich_decision_history(table, state)
    if not isinstance(table, pd.DataFrame) or table.empty:
        st.info("Decision History has no published rows yet. Quick Run now publishes the current direction-confirmation row immediately; historical rows accumulate only from completed broker candles and are never fabricated.")
        return
    preferred = [
        "Date", "Weekday", "Hour",
        "Entry Strength Decision", "SELL Pressure Decision", "BUY Pressure Decision",
        "Pressure Decision", "Pullback Readiness Decision", "M1 Confirmation Decision",
        "Master Decision", "Hold Safety Decision", "TP Quality Decision",
        "Direction Confirmation Decision", "Decision Name", "Final Decision",
        "Outcome Status", "Decision Correct",
    ]
    shown = table.loc[:, [c for c in preferred if c in table.columns]].copy()
    st.dataframe(shown, use_container_width=True, hide_index=True, height=520)
    latest = table.iloc[0].to_dict()
    decision_cols = [c for c in preferred if c.endswith("Decision") and c in latest]
    directional = [str(latest.get(c, "")).upper() for c in decision_cols]
    buy = sum("BUY" in v for v in directional)
    sell = sum("SELL" in v for v in directional)
    available = sum(v not in {"", "N/A", "NONE", "MISSING"} for v in directional)
    cols = st.columns(4)
    cols[0].metric("BUY Decisions", buy)
    cols[1].metric("SELL Decisions", sell)
    cols[2].metric("Directional Conflict", min(buy, sell))
    cols[3].metric("Decision Coverage", f"{available}/{len(decision_cols)}" if decision_cols else "0/0")
    st.caption("HOLD/NO-TRADE reduction must be validated out of sample. This diagnostic is research-only and does not lower protected production thresholds automatically.")

# Static compatibility marker: "Decision Name","Final Decision"
