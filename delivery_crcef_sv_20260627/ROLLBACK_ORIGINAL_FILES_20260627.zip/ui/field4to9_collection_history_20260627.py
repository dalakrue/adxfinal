"""Dinner read-only history and audited evidence aggregation for Fields 4–9."""
from __future__ import annotations
from typing import Any, Mapping, MutableMapping, Iterator
import re
import pandas as pd

_TIME_TOKENS=("broker candle","broker time","completed candle","timestamp","datetime","event time","time","date")
_VALUE_TOKENS=("decision","bias","direction","action","signal","priority","stance","recommendation","outlook","label","trend")
_EXCLUDED_DIRECTION=("confidence","reliability","rank","probability","coverage","score","strength","quality","uncertainty","error","percent","pct")
_GENERATED_KEYS=("field4to9_collection_history","field4_self_calculated","field5_self_calculated","generated table 4","generated table 5")
_FIELDS=("field4","field_4","field 4","field5","field_5","field 5","field6","field_6","field 6","field7","field_7","field 7","field8","field_8","field 8","field9","field_9","field 9","dinner","regime","pattern","research")

def _norm(x:Any)->str:return re.sub(r"[^a-z0-9]+"," ",str(x or "").lower()).strip()
def _is_generated(path:str)->bool:
    n=_norm(path)
    return any(_norm(x) in n for x in _GENERATED_KEYS)
def _field_related(path:str)->bool:
    n=_norm(path)
    return any(_norm(x) in n for x in _FIELDS)

def _walk(obj:Any,path:str="",seen:set[int]|None=None)->Iterator[tuple[str,pd.DataFrame]]:
    seen=seen or set()
    if id(obj) in seen:return
    seen.add(id(obj))
    if isinstance(obj,pd.DataFrame):
        if not obj.empty: yield path or "root",obj
        return
    if isinstance(obj,Mapping):
        for k,v in obj.items():
            yield from _walk(v,f"{path}.{k}" if path else str(k),seen)
    elif isinstance(obj,(list,tuple)):
        if obj and all(isinstance(x,Mapping) for x in obj):
            try:
                df=pd.DataFrame(obj)
                if not df.empty: yield path or "records",df
            except Exception: pass
        for i,v in enumerate(obj):
            if isinstance(v,(Mapping,list,tuple,pd.DataFrame)):
                yield from _walk(v,f"{path}[{i}]",seen)

def _time_col(df:pd.DataFrame):
    cols=list(df.columns)
    for c in cols:
        n=_norm(c)
        if any(t in n for t in _TIME_TOKENS):
            s=pd.to_datetime(df[c],errors="coerce",utc=True)
            if s.notna().any(): return c,s
    if isinstance(df.index,pd.DatetimeIndex):
        return "__index__",pd.Series(pd.to_datetime(df.index,utc=True),index=df.index)
    return None,None

def _broker_display(series:pd.Series,state:Mapping[str,Any]|None=None)->pd.Series:
    # Canonical provider may publish timezone; default is user-required MetaTrader/Myanmar broker display.
    tz=(state or {}).get("broker_timezone") or (state or {}).get("shared_broker_timezone") or "Asia/Yangon"
    try:return series.dt.tz_convert(str(tz))
    except Exception:return series

def build_field4to9_collection_history(state:Mapping[str,Any],canonical:Mapping[str,Any]|None=None)->pd.DataFrame:
    parts=[]; seen_paths=set()
    roots={k:v for k,v in state.items() if _field_related(str(k)) and not _is_generated(str(k))}
    if canonical: roots["canonical_fields_4_9"]=canonical
    for root,obj in roots.items():
        for path,df in _walk(obj,root):
            if path in seen_paths or _is_generated(path):continue
            seen_paths.add(path)
            _,stamp=_time_col(df)
            if stamp is None:continue
            cols=[c for c in df.columns if any(t in _norm(c) for t in _VALUE_TOKENS)]
            if not cols:continue
            part=pd.DataFrame({"Broker Candle Time UTC":stamp})
            for c in cols: part[f"{path} · {c}"]=df[c].to_numpy()
            part=part.dropna(subset=["Broker Candle Time UTC"]).drop_duplicates("Broker Candle Time UTC",keep="last")
            parts.append(part)
    if not parts:return pd.DataFrame(columns=["Broker Candle Time","Date","Weekday","Hour","Source Coverage"])
    out=parts[0]
    for part in parts[1:]:out=out.merge(part,on="Broker Candle Time UTC",how="outer")
    out=out.sort_values("Broker Candle Time UTC",ascending=False)
    latest=out["Broker Candle Time UTC"].max()
    if canonical:
        c=pd.to_datetime(canonical.get("broker_candle_time") or canonical.get("latest_completed_candle_time"),errors="coerce",utc=True)
        if not pd.isna(c):latest=c
    out=out[out["Broker Candle Time UTC"].between(latest-pd.Timedelta(days=25),latest)]
    local=_broker_display(out["Broker Candle Time UTC"],state)
    out.insert(0,"Broker Candle Time",local)
    out.insert(1,"Date",local.dt.strftime("%Y-%m-%d"));out.insert(2,"Weekday",local.dt.strftime("%A"));out.insert(3,"Hour",local.dt.strftime("%H:%M"))
    out.drop(columns=["Broker Candle Time UTC"],inplace=True)
    ev=[c for c in out.columns if c not in {"Broker Candle Time","Date","Weekday","Hour"}]
    out["Source Coverage"]=out[ev].notna().sum(axis=1)
    return out.reset_index(drop=True)

def _direction(value:Any)->str:
    text=_norm(value).upper()
    buy=bool(re.search(r"\b(BUY|BULL|UP|LONG)\b",text)); sell=bool(re.search(r"\b(SELL|BEAR|DOWN|SHORT)\b",text))
    if buy and sell:return "WAIT"
    if buy:return "BUY"
    if sell:return "SELL"
    return "WAIT"

def _category(col:str)->str:
    n=_norm(col)
    if "field 9" in n or "field9" in n:return "Field 9"
    if "field 8" in n or "field8" in n:return "Field 8"
    if "field 7" in n or "field7" in n:return "Field 7"
    if "field 6" in n or "field6" in n:return "Field 6"
    if any(x in n for x in ("sentiment","nlp","news")):return "Sentiment"
    if "regime" in n:return "Regime"
    if any(x in n for x in ("pattern","mining")):return "Pattern"
    return "Technical"

def _source_columns(base:pd.DataFrame)->list[str]:
    cols=[]
    for c in base.columns:
        n=_norm(c)
        if c in {"Broker Candle Time","Date","Weekday","Hour","Source Coverage"}:continue
        if _is_generated(c):continue
        if not any(t in n for t in _VALUE_TOKENS):continue
        if any(t in n for t in _EXCLUDED_DIRECTION):continue
        cols.append(c)
    return cols

def build_self_calculated_field45_tables(state:Mapping[str,Any],canonical:Mapping[str,Any]|None=None):
    base=build_field4to9_collection_history(state,canonical)
    src=_source_columns(base)
    audit=pd.DataFrame([{"Category":_category(c),"Source Column":c,"Direction Eligible":True} for c in src])
    rows4=[];rows5=[]
    for _,r in base.iterrows():
        cats={}
        for cat in ["Technical","Sentiment","Regime","Pattern","Field 6","Field 7","Field 8","Field 9"]:
            vals=[_direction(r[c]) for c in src if _category(c)==cat and pd.notna(r[c])]
            buy=vals.count("BUY");sell=vals.count("SELL");total=len(vals)
            cats[cat]=(0 if not total else (buy-sell)/total,total)
        active=[v for v,n in cats.values() if n]
        score=sum(active)/len(active) if active else 0.0
        conflict=(any(v>0 for v in active) and any(v<0 for v in active))
        decision="WAIT" if conflict else ("BUY" if score>0.15 else "SELL" if score<-0.15 else "WAIT")
        row={"Broker Candle Time":r.get("Broker Candle Time"),**{f"{k} Category Score":round(v,4) for k,(v,n) in cats.items()},"Table 4 Decision":decision,"Conflict":conflict,"Coverage Categories":sum(1 for v,n in cats.values() if n),"Source Column Count":len(src)}
        rows4.append(row)
        rows5.append({"Broker Candle Time":r.get("Broker Candle Time"),"Integrated Decision":decision,"BUY Categories":sum(v>0 for v,n in cats.values() if n),"SELL Categories":sum(v<0 for v,n in cats.values() if n),"WAIT Categories":sum(v==0 for v,n in cats.values() if n),"Conflict":conflict,"Integrated Score":round(score,4),"Source Column Count":len(src)})
    return pd.DataFrame(rows4),pd.DataFrame(rows5),audit

def render_field4to9_collection_history(state:MutableMapping[str,Any],canonical:Mapping[str,Any]|None=None):
    import streamlit as st
    t=build_field4to9_collection_history(state,canonical)
    st.markdown("### Dinner History — All Fields 4–9 Decisions and Biases — Last 25 Days")
    st.caption("Recursive, non-truncated extraction of original timestamped decision/bias/direction/action/signal/priority/stance/recommendation/outlook/label/trend publications, including nested Field 9 data.")
    st.dataframe(t,use_container_width=True,hide_index=True,height=520)
    state["field4to9_collection_history_20260627"]=t
    return t

def render_self_calculated_field45_tables(state:MutableMapping[str,Any],canonical:Mapping[str,Any]|None=None):
    import streamlit as st
    t4,t5,audit=build_self_calculated_field45_tables(state,canonical)
    st.markdown("### Table 4 — Category-Balanced Original Evidence")
    st.dataframe(t4,use_container_width=True,hide_index=True)
    st.markdown("### Table 5 — Integrated Category Consensus")
    st.dataframe(t5,use_container_width=True,hide_index=True)
    with st.expander("Source-column audit — exact original inputs",expanded=False):st.dataframe(audit,use_container_width=True,hide_index=True)
    state["field4_self_calculated_table_20260627"]=t4;state["field5_self_calculated_table_20260627"]=t5;state["field45_source_column_audit_20260627"]=audit
    return t4,t5

__all__=["build_field4to9_collection_history","render_field4to9_collection_history","build_self_calculated_field45_tables","render_self_calculated_field45_tables","_direction","_source_columns"]
