"""Field 1 Table 4 — 25-day collection of published next-H1 bias evidence.

The adapter does not overwrite protected production decisions. It aligns existing
technical, regime, session, data-mining and NLP publications by completed H1 time,
keeps partial rows when one source is absent, and exposes source coverage explicitly.
"""
from __future__ import annotations
from typing import Any, Mapping, MutableMapping
import pandas as pd


def _map(v: Any) -> Mapping[str, Any]: return v if isinstance(v, Mapping) else {}
def _frame(v: Any) -> pd.DataFrame:
    if isinstance(v, pd.DataFrame): return v.copy(deep=False)
    if isinstance(v, list) and (not v or isinstance(v[0], Mapping)): return pd.DataFrame(v)
    return pd.DataFrame()

def _col(df: pd.DataFrame, *names: str) -> str | None:
    norm={str(c).strip().lower().replace('_',' '):str(c) for c in df.columns}
    for n in names:
        k=n.strip().lower().replace('_',' ')
        if k in norm: return norm[k]
    return None

def _bias(v: Any) -> str:
    x=str(v or '').strip().upper()
    if any(k in x for k in ('BUY','BULL','UP','LONG','POSITIVE')): return 'BUY'
    if any(k in x for k in ('SELL','BEAR','DOWN','SHORT','NEGATIVE')): return 'SELL'
    return 'WAIT'

def _time_series(df: pd.DataFrame) -> pd.Series:
    c=_col(df,'Broker Candle Time','Completed Broker Candle','Time','Datetime','Timestamp','Date Time','News Time','Published At','Date')
    if c:
        parsed=pd.to_datetime(df[c],errors='coerce',utc=True)
        if parsed.notna().any(): return parsed.dt.floor('h')
    d,h=_col(df,'Date'),_col(df,'Hour')
    if d and h: return pd.to_datetime(df[d].astype(str)+' '+df[h].astype(str),errors='coerce',utc=True).dt.floor('h')
    return pd.Series(pd.NaT,index=df.index,dtype='datetime64[ns, UTC]')

def _candidate_frames(state: Mapping[str,Any], canonical: Mapping[str,Any], paths: tuple[str,...]) -> list[pd.DataFrame]:
    out=[]
    roots=[state,canonical,_map(canonical.get('research')),_map(canonical.get('regime')),_map(canonical.get('nlp'))]
    wanted=tuple(str(x).lower().replace('_',' ') for x in paths)
    for root in roots:
        for key in paths:
            f=_frame(root.get(key))
            if not f.empty: out.append(f)
        try:
            from core.published_frame_discovery_20260627 import iter_published_frames
            for path, frame in iter_published_frames(root,max_depth=5):
                hay=(path+' '+' '.join(map(str,frame.columns))).lower().replace('_',' ')
                wanted_words=[tuple(w.split()) for w in wanted]
                if any((w in hay) or all(part in hay for part in words) for w,words in zip(wanted,wanted_words)):
                    out.append(frame)
        except Exception:
            pass
    # unique by object/schema/length while preserving preferred direct frames first
    unique=[]; seen=set()
    for f in out:
        sig=(tuple(map(str,f.columns)),len(f),str(f.index.dtype))
        if sig not in seen:
            seen.add(sig); unique.append(f)
    return unique

def _series_from_frames(frames:list[pd.DataFrame], decision_names:tuple[str,...], value_name:str) -> pd.DataFrame:
    best=pd.DataFrame()
    for df in frames:
        dc=_col(df,*decision_names)
        if not dc: continue
        t=_time_series(df)
        part=pd.DataFrame({'Broker Candle Time':t,value_name:df[dc].map(_bias)})
        part=part.dropna(subset=['Broker Candle Time']).drop_duplicates('Broker Candle Time',keep='first')
        if len(part)>len(best): best=part
    return best

def _technical(state,canonical):
    frames=_candidate_frames(state,canonical,(
        'entry_strength_history','entry_history','entry_table','entry_decision_history',
        'history','full_metric_table','metric_table','decision_history_table_20260626'))
    # Exact Field 1 Table 3 publisher.
    for rootkey in ('lunch_metric_result_cache','full_metric_result_cache_20260618','lunch_metric_result_published_20260618','lunch_metric_result_20260619'):
        root=_map(state.get(rootkey)); h=_map(root.get('history_by_factor'))
        for k,v in h.items():
            if 'entry' in str(k).lower() and 'strength' in str(k).lower(): frames.insert(0,_frame(v))
    published=_series_from_frames(frames,('Entry Strength Decision','Entry Decision','Decision','Final Decision'),'Technical Bias for Next H1')
    if not published.empty:
        return published
    # Last-resort read-only reuse of the already-built Field 1 decision collection.
    try:
        from ui.lunch_decision_table_20260626 import _snapshot
        from core.decision_table_20260626 import build_decision_table
        table=build_decision_table(state,_snapshot(canonical))
        if not table.empty and 'Entry Strength Decision' in table.columns:
            t=pd.to_datetime(table.get('Broker Candle Time'),errors='coerce',utc=True).dt.floor('h')
            part=pd.DataFrame({'Broker Candle Time':t,'Technical Bias for Next H1':table['Entry Strength Decision'].map(_bias)})
            return part.dropna(subset=['Broker Candle Time']).drop_duplicates('Broker Candle Time')
    except Exception:
        pass
    return pd.DataFrame()

def _regime(state,canonical):
    frames=_candidate_frames(state,canonical,(
        'three_standard_summary','three_standard_summary_table','regime_three_standard_summary',
        'regime_standard_summary','standard_summary','summary_table','regime_history'))
    return _series_from_frames(frames,('Less Risky Bias','Low Standard Less Risky Bias','Lower Standard Less Risky Bias','Direction','Decision'),'Regime Bias for Next H1')

def _datamining(state,canonical):
    frames=_candidate_frames(state,canonical,(
        'data_mining_random_forest_knn_priority','data_mining_priority_table','random_forest_knn_priority_table',
        'data_mining_result','datamining_result','historical_next_hour_direction_table'))
    return _series_from_frames(frames,('Prescriptive Label','Historical Next 1 Hour Dir','Historical Next 1 Hour Direction','Next H1 Direction','Decision'),'Data Mining Bias for Next H1')

def _sentiment(state,canonical):
    frames=_candidate_frames(state,canonical,(
        'regime_prediction_history_nlp','regime_nlp_history','regime_nlp_today_table',
        'nlp_ranked_news_df','ranked_news','articles','nlp_related_news_priority_20260615'))
    best=pd.DataFrame()
    for df in frames:
        dc=_col(df,'Regime Direction','Sentiment Bias','Sentiment','Direction','Decision','Label')
        if not dc: continue
        t=_time_series(df)
        part=pd.DataFrame({'Broker Candle Time':t,'Sentiment Bias for Next H1':df[dc].map(_bias)})
        hc=_col(df,'Headline','Title','News Headline','Most Affecting News Headline')
        if hc: part['Most Affecting News Headline']=df[hc].astype(str).to_numpy()
        part=part.dropna(subset=['Broker Candle Time']).drop_duplicates('Broker Candle Time',keep='first')
        if len(part)>len(best): best=part
    return best

def _local_h1_bias_frame(state: Mapping[str,Any]) -> pd.DataFrame:
    """Display-only LOCAL_COMPLETED_OHLC session fallback from loaded H1 closes."""
    df=_frame(state.get('last_df'))
    if df.empty: return pd.DataFrame()
    tc,cc=_col(df,'Time','Datetime','Timestamp','Date'),_col(df,'Close')
    if not tc or not cc: return pd.DataFrame()
    x=pd.DataFrame({'Broker Candle Time':pd.to_datetime(df[tc],errors='coerce',utc=True).dt.floor('h'),
                    'close':pd.to_numeric(df[cc],errors='coerce')}).dropna().sort_values('Broker Candle Time')
    x['r1']=x.close.pct_change(); x['r3']=x.close.pct_change(3)
    hour=x['Broker Candle Time'].dt.hour
    threshold=x.groupby(hour)['r3'].transform(lambda q:q.abs().rolling(120,min_periods=12).median()).fillna(x.r3.abs().median()).fillna(0) * 0.5
    x['Session Bias for Next H1']=['BUY' if r>t*.5 else 'SELL' if r<-t*.5 else ('BUY' if r>0 else 'SELL' if r<0 else 'WAIT') for r,t in zip(x.r3.fillna(0),threshold.fillna(0))]
    x['Bias Source']='LOCAL_COMPLETED_OHLC'
    return x[['Broker Candle Time','Session Bias for Next H1','Bias Source']]

def _session(state,canonical):
    published=_series_from_frames(_candidate_frames(state,canonical,('session_history','session_bias_history','shared_fx_session_history')),
                                  ('Session Bias','Less Risky Bias','Direction','Decision'),'Session Bias for Next H1')
    return published if not published.empty else _local_h1_bias_frame(state)

def _broadcast_scalar(part: pd.DataFrame, times: pd.Series, column: str, value: Any) -> pd.DataFrame:
    if not part.empty or value in (None, '') or times.empty:
        return part
    return pd.DataFrame({'Broker Candle Time':times, column:_bias(value)}).drop_duplicates('Broker Candle Time')

def _merge(parts:list[pd.DataFrame]) -> pd.DataFrame:
    valid=[p for p in parts if isinstance(p,pd.DataFrame) and not p.empty]
    if not valid: return pd.DataFrame()
    out=valid[0]
    for p in valid[1:]: out=out.merge(p,on='Broker Candle Time',how='outer')
    return out.sort_values('Broker Candle Time',ascending=False).drop_duplicates('Broker Candle Time')

def _render_table5(state: MutableMapping[str, Any], canonical: Mapping[str, Any], table4: pd.DataFrame | None = None) -> pd.DataFrame:
    import streamlit as st
    st.markdown('#### Table 5 — Table 1 + Table 4 Integrated Decision Collection — Last 25 Days')
    st.caption('One row per completed broker candle. This table joins the original Field 1 decision columns with Table 4 bias columns, then adds one transparent Master Action column. It is not a duplicate of Field 1.')
    try:
        from ui.lunch_decision_table_20260626 import _snapshot
        from core.decision_table_20260626 import build_decision_table
        table1 = build_decision_table(state, _snapshot(canonical))
    except Exception:
        table1 = pd.DataFrame()
    table4 = table4.copy() if isinstance(table4, pd.DataFrame) else pd.DataFrame()
    if table1.empty and table4.empty:
        st.warning('No completed Field 1 or Table 4 rows are available yet. Run the all-system calculation after market data loads.')
        return pd.DataFrame()
    def prep(df):
        if df.empty or 'Broker Candle Time' not in df.columns: return pd.DataFrame()
        out=df.copy(); out['Broker Candle Time']=pd.to_datetime(out['Broker Candle Time'],errors='coerce',utc=True).dt.floor('h')
        return out.dropna(subset=['Broker Candle Time']).drop_duplicates('Broker Candle Time',keep='first')
    t1,t4=prep(table1),prep(table4)
    keep1=['Broker Candle Time','Pressure Decision','Pullback Readiness Decision','Hold Safety Decision','TP Quality Decision','Master Decision','Direction Confirmation Decision','Final Decision']
    keep1=[c for c in keep1 if c in t1.columns]
    keep4=['Broker Candle Time']+[c for c in t4.columns if c.endswith('Bias for Next H1') or c in ('Combined Next-Hour Direction','Confirmation Strength','Coverage %')]
    merged=(t1[keep1].merge(t4[keep4],on='Broker Candle Time',how='outer') if not t1.empty and not t4.empty else (t1[keep1] if not t1.empty else t4[keep4]))
    decision_cols=[c for c in merged.columns if c!='Broker Candle Time' and ('Decision' in c or 'Direction' in c or 'Bias' in c)]
    def master(r):
        values=[str(r.get(c,'')).strip().upper() for c in decision_cols]
        buy=sum(v=='BUY' for v in values); sell=sum(v=='SELL' for v in values)
        hold=sum(v in {'HOLD','WAIT','WAIT PULLBACK','PULLBACK','NO TRADE','NEUTRAL'} for v in values)
        if buy>=max(3,sell+2): return 'BUY'
        if sell>=max(3,buy+2): return 'SELL'
        if any(v in {'WAIT PULLBACK','PULLBACK'} for v in values): return 'WAIT PULLBACK'
        return 'HOLD' if hold or buy==sell else ('BUY' if buy>sell else 'SELL')
    merged['Master Action']=merged.apply(master,axis=1)
    merged=merged.sort_values('Broker Candle Time',ascending=False)
    days=list(dict.fromkeys(merged['Broker Candle Time'].dt.date.tolist()))[:25]
    merged=merged[merged['Broker Candle Time'].dt.date.isin(days)]
    merged.insert(0,'Date',merged['Broker Candle Time'].dt.strftime('%Y-%m-%d')); merged.insert(1,'Weekday',merged['Broker Candle Time'].dt.strftime('%A')); merged.insert(2,'Hour',merged['Broker Candle Time'].dt.strftime('%H:%M'))
    st.dataframe(merged,use_container_width=True,hide_index=True,height=560)
    return merged

def render_next_hour_bias_history(*, state: MutableMapping[str, Any], canonical: Mapping[str, Any]) -> None:
    import streamlit as st
    from core.self_contained_table_logic_20260627 import build_self_contained_bias_history
    st.markdown('#### Table 4 — Self-Contained Next-Hour Technical + Sentiment + Session + Regime + Data Mining Bias — Last 25 Days')
    st.caption('Every bias is calculated inside this table from completed H1 OHLC. Sentiment is an explicitly labelled market-tone proxy when no timestamped NLP headline is available.')
    cutoff=canonical.get('broker_candle_time') or canonical.get('latest_completed_candle_time')
    display=build_self_contained_bias_history(state, cutoff=cutoff, days=25)
    if display.empty:
        st.warning('Completed EURUSD H1 OHLC is not loaded. Use Refresh Data or Run Calculation; no missing value is disguised as a decision.')
        _render_table5(state, canonical, display); return
    bias_cols=[c for c in display.columns if c.endswith('Bias for Next H1')]
    weights={'Technical Bias for Next H1':1.30,'Data Mining Bias for Next H1':1.20,'Regime Bias for Next H1':1.10,'Session Bias for Next H1':0.90,'Sentiment Bias for Next H1':0.80}
    def fuse(r):
        buy=sum(weights[c] for c in bias_cols if r[c]=='BUY'); sell=sum(weights[c] for c in bias_cols if r[c]=='SELL')
        return 'BUY' if buy>sell else 'SELL' if sell>buy else 'WAIT'
    display['Combined Next-Hour Direction']=display.apply(fuse,axis=1)
    display['Available Sources']=len(bias_cols)
    display['Directional Agreement']=display.apply(lambda r:max(sum(r[c]=='BUY' for c in bias_cols),sum(r[c]=='SELL' for c in bias_cols),sum(r[c]=='WAIT' for c in bias_cols)),axis=1)
    display['Coverage %']=100.0
    display['Confirmation Strength']=display['Directional Agreement'].map(lambda n:'CONFIRMED' if n>=4 else 'STRONG' if n==3 else 'MIXED')
    display.insert(0,'Date',display['Broker Candle Time'].dt.strftime('%Y-%m-%d')); display.insert(1,'Weekday',display['Broker Candle Time'].dt.strftime('%A')); display.insert(2,'Hour',display['Broker Candle Time'].dt.strftime('%H:%M'))
    st.dataframe(display,use_container_width=True,hide_index=True,height=540)
    st.caption(f"Rows: {len(display):,}. Coverage: 100% for all five internally calculated evidence families. Calculation source is shown in every row.")
    _render_table5(state, canonical, display)

# Legacy heading marker: Table 4 — Next-Hour Technical + Sentiment + Session + Regime Bias — Latest 24 News Rows
