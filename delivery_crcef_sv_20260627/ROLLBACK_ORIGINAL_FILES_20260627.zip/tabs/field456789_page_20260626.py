"""Combined display-only page for original Fields 4, 5, 6, 7, 8 and 9.

Calculation engines remain independent. This page only renders existing published
results together and never starts a calculation. The former embedded Field 5
assistant is intentionally removed; the independent AI Assistant page owns AirLLM.
"""
from __future__ import annotations
import streamlit as st

def show(runtime_context=None):
    from ui.lunch_four_core_fields_20260619 import (
        render_field456_independent, render_field789_independent,
    )
    st.markdown("## 🌙 Dinner — Fields 4–9 Combined Integrated Workspace")
    st.caption("Display combination only. Original Fields 4, 5, 6, 7, 8 and 9 retain independent engines, caches, persistence stores and calculations.")
    st.markdown("---")
    from core.canonical_lookup_20260626 import resolve_canonical
    from ui.field4to9_collection_history_20260627 import render_field4to9_collection_history
    canonical = resolve_canonical(st.session_state)
    render_field4to9_collection_history(st.session_state, canonical)
    from ui.field4to9_collection_history_20260627 import render_self_calculated_field45_tables
    render_self_calculated_field45_tables(st.session_state, canonical)
    st.markdown("---")
    render_field456_independent(state=st.session_state)
    st.markdown("---")
    render_field789_independent(state=st.session_state)
