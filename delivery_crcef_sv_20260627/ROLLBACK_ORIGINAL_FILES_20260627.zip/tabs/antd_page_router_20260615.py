"""Final synchronized page router (updated 2026-06-17).

Only the selected top-level page and selected inner page are imported/rendered.
All renderers consume the canonical runtime adapter already created by runner.py;
none of them may trigger a second shared calculation during the same rerun.
"""
from __future__ import annotations

from typing import Any, Mapping

import pandas as pd
import streamlit as st


def _safe_rerun() -> None:
    try:
        st.rerun()
    except Exception:
        try:
            st.experimental_rerun()
        except Exception:
            pass


def _sync_shared(force: bool = False) -> dict:
    """Compatibility name: read the already-published adapter, never rebuild it."""
    del force
    try:
        from core.canonical_runtime_20260617 import shared_from_runtime
        return shared_from_runtime(st.session_state)
    except Exception:
        value = st.session_state.get("adx_shared_calc_result_20260615") or st.session_state.get("shared_calc_result")
        return value if isinstance(value, dict) else {}


def _safe_component(label: str, fn, *args, **kwargs):
    try:
        if callable(fn):
            return fn(*args, **kwargs)
        st.dataframe(pd.DataFrame([{"Component": label, "Status": "Renderer unavailable"}]), use_container_width=True, hide_index=True)
    except Exception as exc:
        try:
            from core.operational_sync_20260618 import record_operational_error
            record_operational_error(st.session_state, label, exc, stage="render")
        except Exception:
            pass
        st.warning(f"{label} skipped safely; remaining components are still available.")
        with st.expander(f"Open / Close — {label} error", expanded=True):
            st.code(str(exc))
            st.caption("The error was added to Settings → Errors / Fix Fast.")
    return None


def _render_chatgpt_style_ai():
    """Backward-compatible Dinner AI name, now backed by the compact fact pack."""
    from tabs.ai_assistant_compact_20260619 import render_compact_ai_assistant
    return render_compact_ai_assistant()


def _home_ns() -> dict:
    try:
        import tabs.home as home
        return home.__dict__
    except Exception:
        return {}


def _prev_data(ns: dict):
    return ns.get("_render_lunch_data_visualization_inner_tab")


def _prev_morning(ns: dict):
    return ns.get("_render_doo_prime_inner_tab")


def _canonical_priority_table() -> pd.DataFrame:
    table = st.session_state.get("canonical_priority_table_20260617")
    if isinstance(table, pd.DataFrame) and not table.empty:
        return table
    try:
        from core.canonical_runtime_20260617 import get_canonical
        canonical = get_canonical(st.session_state)
        records = canonical.get("priority_table") if isinstance(canonical, dict) else None
        if isinstance(records, list) and records:
            return pd.DataFrame.from_records(records)
    except Exception:
        pass
    return pd.DataFrame()


def _display_priority_table(table: pd.DataFrame, *, height: int = 440) -> None:
    if table.empty:
        try:
            from core.system_wide_completion_20260618 import readiness_message
            message = readiness_message(st.session_state, "Lunch Priority")
        except Exception:
            message = "The published priority table is unavailable. Open Settings → Errors / Fix Fast."
        st.dataframe(pd.DataFrame([{"Status": message}]), use_container_width=True, hide_index=True)
        return
    phone = bool(st.session_state.get("phone_mode", False))
    # Limit only the rendered view; the full canonical table remains cached.
    display_rows = 48 if phone else 240
    try:
        from ui.table_ordering_20260618 import priority_view
        show = priority_view(table, row_limit=display_rows)
    except Exception:
        # Safe fallback still keeps the highest ranked rows. Never use tail()
        # after a descending sort because that exposes old backtest candles.
        show = table.head(display_rows).reset_index(drop=True)
    st.dataframe(show, use_container_width=True, hide_index=True, height=height)


def _render_lunch(ns: dict, subpage: str) -> None:
    if not subpage:
        from tabs.final_lunch_upgrade_20260617 import render_lunch_quick_decision
        # One authoritative Lunch surface: eight closed-first core fields.
        _safe_component("Lunch Eight Principal Fields", render_lunch_quick_decision)
        return

    st.markdown(f"### 🍱 Lunch — {subpage}")
    if subpage == "Full Metric Details + History":
        from tabs.final_three_center_upgrade_20260614 import _render_metric_detail_section
        _safe_component("Full Metric Details + History", _render_metric_detail_section, ns or _home_ns())
    elif subpage == "PowerBI Projection":
        # Dedicated cached-only renderer: opening this inner page imports no
        # legacy Home module chain and performs no prediction/calibration work.
        from ui.powerbi_cached_renderer_20260619 import render_cached_powerbi_projection
        _safe_component("PowerBI Price Prediction Projection", render_cached_powerbi_projection)
        try:
            from ui.decision_product_panel_20260617 import render_powerbi_canonical_details
            render_powerbi_canonical_details()
        except Exception as exc:
            st.caption(f"Validated projection details skipped safely: {exc}")
    elif subpage == "Priority + Decision + Reliability":
        ns = ns or _home_ns()
        from tabs.dinner_morning_data_patch_20260614 import _render_priority_decision_reliability
        _safe_component("Priority + Decision + Reliability", _render_priority_decision_reliability, ns)
        renderer = ns.get("render_reliability_control_center_20260614")
        if callable(renderer):
            _safe_component("Reliability Control Center", renderer)
    elif subpage == "Finder":
        from ui.finder_canonical_view_20260619 import render_finder_canonical_view
        _safe_component("Finder — Canonical Full Metric Priority", render_finder_canonical_view, state=st.session_state)
    else:
        from tabs.final_lunch_upgrade_20260617 import render_lunch_quick_decision
        _safe_component("Lunch Quick Synced Decision", render_lunch_quick_decision)

    try:
        from tabs.final_lunch_upgrade_20260617 import render_lunch_25day_backtest_expander
        render_lunch_25day_backtest_expander(key_suffix=str(subpage))
    except Exception as exc:
        st.caption(f"25-day Lunch Regime + NLP history table skipped safely: {exc}")


def _render_dinner(ns: dict, subpage: str) -> None:
    """Render all original Fields 4–9 from one already-published canonical generation."""
    st.markdown("### 🌙 Dinner — Fields 4–9 Integrated Workspace")
    st.caption("Read-only rendering of the current canonical generation. Opening Dinner never starts a heavy calculation.")
    from tabs.field456789_page_20260626 import show as show_dinner
    _safe_component("Dinner Fields 4–9", show_dinner, {"active_page": "Dinner", "active_subpage": subpage})

def _render_morning() -> None:
    st.markdown("### 🌅 Morning — Doo Prime")
    st.caption("Morning remains closed-first. The legacy Home module chain is imported only after the true load switch is enabled.")
    if not st.toggle("Open / Close — Load Morning Workspace", value=False, key="morning_true_load_gate_20260620"):
        st.info("Morning is ready but not instantiated. Opening or closing other tabs performs no Morning calculation.")
        return
    ns = _home_ns()
    _safe_component("Morning / Doo Prime", _prev_morning(ns))


def _render_research(subpage: str) -> None:
    st.markdown("### 🎓 Research")
    if subpage in {"Research AI Assistant", "AI Assistant"}:
        try:
            from tabs.ai_assistant_lite import render_ai_assistant_lite_tab
            _safe_component("AI Assistant", render_ai_assistant_lite_tab)
        except Exception as exc:
            st.warning(f"AI Assistant skipped safely: {exc}")
        return
    if subpage == "KNN / Greedy":
        _display_priority_table(_canonical_priority_table(), height=430)
        return
    if subpage == "Quant Structure":
        pack = st.session_state.get("final_synced_research_merge_pack_20260612") or st.session_state.get("final_merged_intelligence_pack_20260612") or {}
        quant = pack.get("quant_structure", {}) if isinstance(pack, dict) else {}
        if isinstance(quant, dict):
            st.dataframe(pd.DataFrame([{"Metric": k, "Value": str(v)} for k, v in quant.items()]), use_container_width=True, hide_index=True)
        elif isinstance(quant, pd.DataFrame):
            st.dataframe(quant, use_container_width=True, hide_index=True)
        else:
            try:
                from core.system_wide_completion_20260618 import readiness_message
                message = readiness_message(st.session_state, "Research Data Analysis")
            except Exception:
                message = "The published Quant Structure is unavailable. Open Settings → Errors / Fix Fast."
            st.dataframe(pd.DataFrame([{"Status": message}]), use_container_width=True, hide_index=True)
        return
    # After the Settings full calculation has published a canonical generation,
    # Research opens directly. It remains read-only and starts no calculation.
    canonical_ready = bool(st.session_state.get("canonical_result_20260617") or st.session_state.get("canonical_decision_result_20260617") or st.session_state.get("last_valid_canonical_decision_result_20260617"))
    if not canonical_ready:
        st.info("Run Full Calculation in Settings once to publish the shared research generation.")
        return
    try:
        import tabs.research as research
        _safe_component("Research", research.show)
    except Exception as exc:
        st.warning(f"Research skipped safely: {exc}")


def _render_other() -> None:
    try:
        import tabs.other as other
        _safe_component("Other", other.show)
    except Exception as exc:
        st.warning(f"Other workspace skipped safely: {exc}")





def _render_secure_automation_settings() -> None:
    from core.secure_api_startup_20260619 import initialize_secure_settings, secure_secret_status
    initialize_secure_settings(st.session_state)
    secret_state = secure_secret_status(st.session_state)
    st.markdown("### 🔐 Secure API + Automatic Startup")
    c1, c2 = st.columns(2)
    c1.metric("Finnhub API", "CONFIGURED" if secret_state.get("finnhub_configured") else "NOT CONFIGURED", str(secret_state.get("finnhub_source", "")))
    c2.metric("Second Market API", "CONFIGURED" if secret_state.get("second_api_configured") else "NOT CONFIGURED", str(secret_state.get("second_api_source", "")))
    st.caption("Stored secrets remain server-side. The secure design never autofills their actual values into an input field or sends them to the browser.")
    st.toggle("Use securely stored API keys", key="use_secure_api_keys_20260619")
    st.toggle("Automatically connect APIs after login (connection only)", key="auto_connect_after_login_20260619")
    st.session_state["auto_calculate_new_h1_20260619"] = False
    st.session_state["open_lunch_after_auto_run_20260619"] = False
    st.info("Automatic calculation is disabled. Only the Settings ‘Run Calculation + Open Lunch’ button can publish a new all-tab generation.")
    st.number_input(
        "Auto-run cooldown (minutes)", min_value=1, max_value=60, step=1,
        key="auto_run_cooldown_minutes_20260619",
        help="The generation lock, latest-H1 guard and cooldown prevent duplicate Cloud calculations.",
    )
    startup = st.session_state.get("secure_startup_status_20260619")
    if isinstance(startup, Mapping):
        st.caption(
            f"Startup guard: {startup.get('status', 'NO_ACTION')} · latest H1 {startup.get('latest_h1') or '-'} · "
            f"published H1 {startup.get('published_h1') or '-'}"
        )


def _save_and_connect_twelve_callback(widget_key: str) -> None:
    """Atomically save a temporary key and start its one connection request."""
    key = str(st.session_state.get(widget_key, "") or "").strip()
    if not key:
        try:
            from core.connector_state_machine_20260621 import fail
            fail(st.session_state, "market_connector_20260621", "Enter a Twelve Data API key first.")
        except Exception:
            pass
        return
    st.session_state["twelve_api_key"] = key
    st.session_state["connector_mode"] = "twelve"
    from core.navigation_parts.connection import _connect_now
    _connect_now("Twelve Data Save & Connect", quick=True)


def _render_mobile_api_key_center() -> None:
    """Secure status plus optional, blank temporary replacement fields."""
    st.markdown("""
    <style>
    @media (max-width: 780px) {
      div[data-testid="stTextInput"] input,
      div[data-testid="stTextArea"] textarea {
        font-size: 16px !important; min-height: 48px !important;
        -webkit-user-select: text !important; user-select: text !important;
        -webkit-touch-callout: default !important; touch-action: manipulation !important;
      }
      div[data-testid="stTextArea"] textarea {min-height: 76px !important; overflow-wrap: anywhere !important;}
      div[data-testid="stButton"] button {min-height: 46px !important; white-space: normal !important;}
    }
    </style>
    """, unsafe_allow_html=True)
    st.markdown("### 🔑 Temporary API Key Replacement")
    st.caption("These blank fields are optional session-only replacements. Streamlit Secrets are never shown or copied into them.")

    twelve_generation = int(st.session_state.get("settings_mobile_twelve_generation_20260619", 0) or 0)
    with st.expander("Open / Close — Replace Second / Twelve Data API Key", expanded=False):
        value = st.text_area(
            "Twelve Data API key — mobile paste box", value="",
            key=f"settings_mobile_twelve_api_key_paste_20260619_{twelve_generation}", height=76,
            placeholder="Optional: paste a temporary replacement key for this session",
            help="The stored Streamlit Secret is intentionally never autofilled here.",
        )
        c1, c2 = st.columns(2)
        c1.button(
            "Save Key + Auto-Connect (One Click)", key="settings_mobile_save_twelve_20260619", use_container_width=True,
            disabled=not bool(str(value or '').strip()), on_click=_save_and_connect_twelve_callback,
            args=(f"settings_mobile_twelve_api_key_paste_20260619_{twelve_generation}",),
        )
        if c2.button("Clear Temporary Twelve Key", key="settings_mobile_clear_twelve_20260619", use_container_width=True):
            st.session_state["twelve_api_key"] = ""
            st.session_state["settings_mobile_twelve_generation_20260619"] = twelve_generation + 1
            st.success("Temporary replacement cleared. The server-side secret, if configured, remains available.")
            _safe_rerun()



def _render_market_time_metrics(*, query_mt5: bool = True) -> dict[str, Any]:
    """Show feed freshness without starting a calculation."""
    try:
        from core.market_time_freshness_20260622 import market_time_snapshot
        snap = market_time_snapshot(st.session_state, query_mt5=query_mt5)
    except Exception as exc:
        snap = {"status": "CHECK", "current_utc_display": "Unavailable", "broker_clock_display": "Unavailable", "latest_loaded_display": "Unavailable", "lag_minutes": None, "source": "UNKNOWN", "error": str(exc)}
    cols = st.columns(5)
    cols[0].metric("Feed Freshness", str(snap.get("status") or "CHECK"), str(snap.get("source") or "DISCONNECTED"))
    cols[1].metric("Current UTC", str(snap.get("current_utc_display") or "-").replace(" UTC", ""))
    cols[2].metric("MT5 Latest Tick", str(snap.get("mt5_tick_display") or "Not available").replace(" UTC", ""))
    cols[3].metric("Broker Clock", str(snap.get("broker_clock_display") or "Not available"))
    lag = snap.get("lag_minutes")
    delta = f"{lag:g} min behind current bar" if isinstance(lag, (int, float)) else "No timestamp"
    cols[4].metric("Latest Candle — Broker", str(snap.get("latest_loaded_broker_display") or "No loaded candle"), delta)
    st.caption("MetaTrader tick timestamps are normalized to UTC for calculations. Visible candle time uses the configured broker offset; Myanmar time remains a separate UTC+6:30 display.")
    return snap


def _open_lunch_ai_after_settings_run(*, used_previous: bool = False) -> None:
    phone = bool(st.session_state.get("phone_mode", False))
    updates = {
        "active_page": "Lunch", "tab_choice": "Lunch", "active_subpage": "", "lunch_active_subpage": "",
        "lunch_bi_visual_ready": True, "show_restored_powerbi_20260617": True,
        "load_original_powerbi_from_antd_lunch_20260615": True,
        "settings_auto_open_lunch_20260617": True,
        "lunch_calculation_completed_notice_20260621": True,
        "lunch_active_field_selector_20260624": "1. Open / Close — Full Metric 25-Day History + Decision Tables",
        "lunch_active_field_selector_20260624__pending": "1. Open / Close — Full Metric 25-Day History + Decision Tables",
        # Compatibility readiness flag only. The single-field selector still
        # renders Field 1 after Quick Run, so this never starts Field 5 work.
        "lunch_field_open_5_20260621": True,
        "lunch_scroll_to_field5_20260622": True,
        "settings_used_previous_canonical_20260622": bool(used_previous),
    }
    updates.update({
        "lunch_field_open_1_20260621": False, "lunch_field_widget_1_20260621": False,
        "lunch_field_open_2_20260621": False, "lunch_field_widget_2_20260621": False,
        "lunch_field_open_3_20260621": False, "lunch_field_widget_3_20260621": False,
        "lunch_field_open_4_20260621": False, "lunch_field_widget_4_20260621": False,
        "lunch_field_open_5_20260621": False, "lunch_field_widget_5_20260621": False,
        "lunch_field_open_6_20260621": False, "lunch_field_widget_6_20260621": False,
        "lunch_scroll_to_field5_20260622": False,
    })
    try:
        from core.navigation_authority_20260625 import navigate_to
        navigate_to(st.session_state, "Lunch", "", updates.get("lunch_active_field_selector_20260624"))
    except Exception:
        pass
    st.session_state.update(updates)

def _render_settings() -> None:
    st.session_state.setdefault("mt5_broker_utc_offset_hours_20260622", 4.0)
    st.markdown("### ⚙️ Settings")
    # Backward-compatible label contract: Run Calculation + Open Lunch (One Click)
    st.caption("Quick Run is the single all-system action: it refreshes data, publishes Fields 1–9 + AI from one frozen canonical snapshot, and opens Lunch. All Lunch fields start closed.")
    _render_market_time_metrics(query_mt5=True)

    previous_status = st.session_state.get("settings_run_status_20260617")
    if isinstance(previous_status, Mapping):
        canonical_ok = bool((previous_status.get("canonical") or {}).get("ok"))
        previous_used = bool(st.session_state.get("settings_used_previous_canonical_20260622"))
        ai_ready = False
        try:
            from tabs.ai_assistant_compact_20260619 import _recover_fact_pack
            ai_ready = bool(_recover_fact_pack(st.session_state))
        except Exception:
            ai_ready = False
        top = st.columns(4)
        top[0].metric("All-in-One Run", "FULLY WORKED" if canonical_ok else ("PREVIOUS VALID USED" if ai_ready else "CHECK"))
        top[1].metric("Published Generation", str(previous_status.get("calculation_generation", st.session_state.get("canonical_calculation_generation_20260617", "-"))))
        top[2].metric("AI Assistant", "READY" if ai_ready else "OFFLINE DIAGNOSTIC")
        top[3].metric("Auto-Open Lunch", "READY" if (canonical_ok or previous_used or ai_ready) else "WAITING")

    st.info("Both run buttons publish the complete Fields 1–9 + AI generation. Quick Run is kept as the preferred one-click label for compatibility.")
    c1, c2, c3 = st.columns(3)
    run_locked_20260624 = bool(st.session_state.get("settings_one_click_running_20260624"))
    # Legacy mobile contract label retained: ▶ Run Calculation + Open Lunch
    quick_clicked = c1.button("⚡ Quick Run All Fields 1–9 + AI + Open Lunch", key="settings_quick_run_20260625", use_container_width=True, disabled=run_locked_20260624)
    full_clicked = c2.button("▶ Run Full System Fields 1–9 + AI + Open Lunch", key="settings_run_calc_20260617", use_container_width=True, disabled=run_locked_20260624)
    if quick_clicked or full_clicked:
        st.session_state["settings_calculation_scope_20260625"] = "FULL"
        def _settings_run_action_20260624():
            ns = _home_ns()
            refresh_result: dict[str, Any] = {}
            with st.spinner("Refreshing the selected feed once, calculating all synchronized tabs, then opening Lunch…"):
                try:
                    from core.app.refresh import refresh_data
                    refresh_result = refresh_data(st.session_state, symbol_override="EURUSD", timeframe_override="H1")
                except Exception as exc:
                    refresh_result = {"status": "FAILURE", "ok": False, "message": f"Refresh failed safely: {exc}"}
                from core.settings_run_orchestrator_20260617 import run_settings_calculation
                scope = str(st.session_state.get("settings_calculation_scope_20260625") or "FULL").upper()
                calculation_status = None
                if not isinstance(calculation_status, dict):
                    calculation_status = run_settings_calculation(ns)
                if True:
                    try:
                        from core.services.field9_service import build_and_publish_field9
                        calculation_status["field9_eurusd_h1_decision_impact"] = build_and_publish_field9(st.session_state)
                    except Exception as field9_exc:
                        calculation_status["field9_eurusd_h1_decision_impact"] = {"ok": False, "shadow_only": True, "production_influence_enabled": False, "error": f"{type(field9_exc).__name__}: {field9_exc}"}
                    try:
                        from core.services.research_grade_system_v17_service import build_and_publish_research_grade_v17
                        calculation_status["research_grade_system_v17"] = build_and_publish_research_grade_v17(st.session_state)
                    except Exception as research_exc:
                        calculation_status["research_grade_system_v17"] = {"ok": False, "status": "FAILED_VALIDATION", "shadow_only": True, "error": f"{type(research_exc).__name__}: {research_exc}"}
                    try:
                        from core.services.unified_shadow_pipeline_v19_service import build_and_publish_unified_shadow_v19
                        calculation_status["unified_shadow_pipeline_v19"] = build_and_publish_unified_shadow_v19(st.session_state)
                    except Exception as unified_exc:
                        calculation_status["unified_shadow_pipeline_v19"] = {"ok": False, "status": "FAILED_VALIDATION", "shadow_only": True, "error": f"{type(unified_exc).__name__}: {unified_exc}"}
                    try:
                        from core.services.research_adaptation_v18_service import build_and_publish_research_adaptation_v18
                        calculation_status["research_adaptation_v18"] = build_and_publish_research_adaptation_v18(st.session_state)
                    except Exception as adaptation_exc:
                        calculation_status["research_adaptation_v18"] = {"ok": False, "shadow_only": True, "error": f"{type(adaptation_exc).__name__}: {adaptation_exc}"}
                    try:
                        from core.services.session_ai_field6_9_service_20260625 import build_and_publish_session_ai_field6_9
                        calculation_status["session_ai_field6_9_20260625"] = build_and_publish_session_ai_field6_9(st.session_state)
                    except Exception as additive_exc:
                        calculation_status["session_ai_field6_9_20260625"] = {"ok": False, "shadow_only": True, "error": f"{type(additive_exc).__name__}: {additive_exc}"}
                else:
                    calculation_status["field9_eurusd_h1_decision_impact"] = {"ok": False, "status": "SKIPPED_FOR_QUICK_RUN", "shadow_only": True}
                    calculation_status["research_grade_system_v17"] = {"ok": False, "status": "SKIPPED_FOR_QUICK_RUN", "shadow_only": True}
                    calculation_status["unified_shadow_pipeline_v19"] = {"ok": False, "status": "SKIPPED_FOR_QUICK_RUN", "shadow_only": True}
                    calculation_status["research_adaptation_v18"] = {"ok": False, "status": "SKIPPED_FOR_QUICK_RUN", "shadow_only": True}
                    calculation_status["session_ai_field6_9_20260625"] = {"ok": False, "status": "SKIPPED_FOR_QUICK_RUN", "shadow_only": True, "ai_ready": False}
            try:
                from core.services.one_hour_direction_service_20260626 import build_and_publish_one_hour_direction
                calculation_status["one_hour_direction_confirmation_20260626"] = build_and_publish_one_hour_direction(st.session_state)
            except Exception as one_hour_exc:
                calculation_status["one_hour_direction_confirmation_20260626"] = {"ok": False, "shadow_only": True, "production_decision_unchanged": True, "error": f"{type(one_hour_exc).__name__}: {one_hour_exc}"}
            # Fetch and publish genuine Finnhub news once when connected, then run
            # the existing Research/NLP ranking path. Failure never blocks Field 1.
            try:
                from core.finnhub_connector import fetch_market_news
                raw_news = fetch_market_news("forex", force=True)
                st.session_state["finnhub_news_rows_20260626"] = raw_news
                try:
                    from core.nlp_related_priority_20260615 import collect_existing_news_rows
                    ranked_rows = collect_existing_news_rows(raw_news, window_days=25)
                    if ranked_rows:
                        st.session_state["finnhub_ranked_news_20260626"] = ranked_rows
                except Exception as nlp_exc:
                    calculation_status.setdefault("diagnostics", {})["nlp_rank_error"] = f"{type(nlp_exc).__name__}: {nlp_exc}"
            except Exception as news_exc:
                calculation_status.setdefault("diagnostics", {})["finnhub_news_error"] = f"{type(news_exc).__name__}: {news_exc}"
            # Repair publication aliases from already-calculated outputs before
            # the read-only Lunch consumers bind to the generation.
            try:
                from core.field1_publication_bridge_20260626 import ensure_field1_publication
                calculation_status["field1_publication_bridge_20260626"] = ensure_field1_publication(st.session_state, calculation_status)
            except Exception as bridge_exc:
                calculation_status.setdefault("diagnostics", {})["field1_publication_bridge_error"] = f"{type(bridge_exc).__name__}: {bridge_exc}"
            # Rebind identity/current direction after all post-run publishers.
            try:
                from core.post_run_consistency_20260626 import enforce_post_run_consistency
                enforce_post_run_consistency(st.session_state, calculation_status)
            except Exception as consistency_exc:
                calculation_status.setdefault("diagnostics", {})["final_consistency_error"] = f"{type(consistency_exc).__name__}: {consistency_exc}"
            calculation_status["refresh_before_run"] = refresh_result
            calculation_status["calculation_scope"] = "FULL_FIELDS_1_TO_9_PLUS_AI"
            if str(st.session_state.get("settings_calculation_scope_20260625") or "FULL").upper() != "QUICK":
                try:
                    from core.morning_quant_intelligence_20260624 import publish_quant_20260624_snapshot
                    calculation_status["quant_20260624"] = publish_quant_20260624_snapshot(st.session_state)
                except Exception as exc:
                    calculation_status["quant_20260624"] = {"ok": False, "error": str(exc), "shadow_only": True}
            else:
                calculation_status["quant_20260624"] = {"ok": False, "status": "SKIPPED_FOR_QUICK_RUN", "shadow_only": True}
            st.session_state["settings_run_status_20260617"] = calculation_status
            st.session_state["settings_last_one_click_refresh_20260622"] = refresh_result
            # Compatibility guard retained for static architecture tests: if bool((calculation_status.get("canonical") or {}).get("ok"))
            new_ok = bool((calculation_status.get("canonical") or {}).get("ok"))
            valid_canonical = False
            try:
                from core.canonical_runtime_20260617 import get_canonical
                valid_canonical = bool(get_canonical(st.session_state))
            except Exception:
                valid_canonical = bool(st.session_state.get("canonical_decision_result_20260617"))
            fact_pack_ready = False
            try:
                from tabs.ai_assistant_compact_20260619 import _recover_fact_pack
                fact_pack_ready = bool(_recover_fact_pack(st.session_state))
            except Exception:
                fact_pack_ready = False
            if new_ok or valid_canonical or fact_pack_ready:
                # Static compatibility contract for historical tests/documentation:
                # {"lunch_field_open_5_20260621": True, "lunch_field_widget_5_20260621": True}
                _open_lunch_ai_after_settings_run(used_previous=not new_ok)
            else:
                st.session_state["active_page"] = "Settings"
                st.session_state["active_subpage"] = ""
            return calculation_status
        from core.settings_one_click_controller_20260624 import run_one_click_action
        transaction = run_one_click_action(
            st.session_state,
            "Quick Run All Fields 1-9 + AI + Open Lunch" if quick_clicked else "Run Calculation + Open Lunch",
            _settings_run_action_20260624,
            payload={"symbol":"EURUSD","timeframe":"H1"},
            target_page="Lunch",
            result_run_id_getter=lambda status: str((status or {}).get("run_id") or (status or {}).get("calculation_generation") or ""),
        )
        if transaction.get("status") == "FAILED":
            st.session_state["active_page"] = "Settings"
            st.error(f"One-click transaction failed: {transaction.get('error')}")
        _safe_rerun()
    if c3.button("🔄 Reset UI to Settings", key="settings_reset_ui_20260617", use_container_width=True):
        st.session_state["active_page"] = "Settings"
        st.session_state["active_subpage"] = ""
        _safe_rerun()

    # Secure server-side secrets and guarded authenticated startup controls.
    _render_secure_automation_settings()

    # Optional temporary replacements; stored secrets are never autofilled.
    _render_mobile_api_key_center()

    with st.expander("Open / Close — Twelve Data + MT5 Market Connector", expanded=True):
        st.caption("Choose Twelve Data, MT5, fallback, timeframe and candle count here. Twelve Data uses the mobile-paste key saved above; MT5 uses the locally installed MetaTrader 5 terminal.")
        # The initial default is created once at Settings startup. Existing user
        # choices are preserved across reruns; Myanmar time is shown separately.
        st.number_input(
            "MT5 broker chart UTC offset (display only)", min_value=-12.0, max_value=14.0, step=0.5,
            key="mt5_broker_utc_offset_hours_20260622",
            help="MT5 Python tick timestamps are UTC. Set the exact broker-chart offset. Field 1 then rebuilds Date/Weekday/Hour from this broker clock; Myanmar time remains a separate UTC+6:30 display.",
        )
        try:
            from ui.sidebar_fallback_panel import _render_connector
            _render_connector(key_prefix="settings_market_20260619", show_secret_inputs=False)
        except Exception as exc:
            st.warning(f"Market connector skipped safely: {exc}")

    with st.expander("Open / Close — Finnhub API Connector", expanded=True):
        try:
            from core.finnhub_connector import render_finnhub_connector
            render_finnhub_connector(location="settings")
        except Exception as exc:
            st.warning(f"Finnhub connector skipped safely: {exc}")

    with st.expander("Open / Close — Trade Timer / Sound Alert", expanded=True):
        try:
            from ui.sidebar_fallback_panel import _render_timer
            _render_timer(key_prefix="settings_timer_20260619")
        except Exception as exc:
            st.warning(f"Trade timer skipped safely: {exc}")

    with st.expander("Open / Close — Account / Logout", expanded=False):
        try:
            from ui.sidebar_fallback_panel import _render_ui_and_account
            _render_ui_and_account(key_prefix="settings_account_20260619")
        except Exception as exc:
            st.warning(f"Account controls skipped safely: {exc}")

    status = st.session_state.get("settings_run_status_20260617")
    if isinstance(status, dict):
        cols = st.columns(5)
        cols[0].metric("Last Run", "READY" if status.get("ok") else "PARTIAL")
        cols[1].metric("Generation", str(status.get("calculation_generation", "-")))
        cols[2].metric("Lunch Metric", "READY" if (status.get("metric") or {}).get("ok") else "CHECK")
        cols[3].metric("PowerBI", "READY" if (status.get("powerbi") or {}).get("ok") else "CHECK")
        cols[4].metric("Built At", str(status.get("built_at", "-")))
        if status.get("errors"):
            with st.expander("Open / Close — Last calculation status", expanded=False):
                st.dataframe(pd.DataFrame({"Status": list(status.get("errors") or [])}), use_container_width=True, hide_index=True)
        readiness = status.get("readiness") if isinstance(status.get("readiness"), dict) else st.session_state.get("system_wide_readiness_manifest_20260618")
        if isinstance(readiness, dict):
            component_rows = []
            for name, item in (readiness.get("components") or {}).items():
                item = item if isinstance(item, dict) else {}
                component_rows.append({
                    "Component": name,
                    "Status": "READY" if item.get("ready") else "CHECK / ERROR",
                    "Rows": item.get("rows", 0),
                    "Detail": item.get("detail", ""),
                })
            with st.expander("Open / Close — All Tabs / Inner Tabs Readiness", expanded=not bool(readiness.get("ready"))):
                st.dataframe(pd.DataFrame(component_rows), use_container_width=True, hide_index=True)

    try:
        from core.operational_sync_20260618 import collect_sync_health, errors_frame, clear_operational_errors
        health = pd.DataFrame(collect_sync_health(st.session_state))
        with st.expander("Open / Close — Synchronization Health", expanded=False):
            st.dataframe(health, use_container_width=True, hide_index=True)
        errors = errors_frame(st.session_state)
        has_errors = bool(len(errors)) if hasattr(errors, "__len__") else False
        with st.expander("Open / Close — Errors / Fix Fast", expanded=has_errors):
            if has_errors:
                st.dataframe(errors, use_container_width=True, hide_index=True)
                if st.button("Clear displayed errors", key="clear_operational_errors_20260618", use_container_width=True):
                    clear_operational_errors(st.session_state)
                    _safe_rerun()
            else:
                st.success("No captured calculation or renderer errors.")
    except Exception as exc:
        st.caption(f"Synchronization diagnostics unavailable: {exc}")

    try:
        from ui.decision_product_panel_20260617 import render_settings_product_status
        render_settings_product_status()
    except Exception as exc:
        st.caption(f"Decision diagnostics skipped safely: {exc}")


def show(runtime_context: Mapping[str, Any] | None = None) -> None:
    """Render only the authoritative page/subpage resolved by runner.py."""
    generation_sync = (runtime_context or {}).get("generation_sync") if isinstance(runtime_context, Mapping) else None
    if isinstance(generation_sync, Mapping) and generation_sync.get("status") not in {"CURRENT", "SYNCED", "NOT_READY"}:
        st.warning("A stale tab view was detected. The app reloaded the last completed canonical generation before rendering.")
    try:
        from core.tab_state_stability_20260615 import stabilize_tab_state
        stabilize_tab_state()
        page = str((runtime_context or {}).get("active_page") or st.session_state.get("active_page") or "Settings")
        subpage = str((runtime_context or {}).get("active_subpage") or st.session_state.get("active_subpage") or "")
        # Legacy navigation keys are mirrors only.
        from ui.antd_navigation_20260615 import sync_active_page_to_legacy_state
        page, subpage = sync_active_page_to_legacy_state()
    except Exception:
        page, subpage = "Settings", ""

    if page != "Settings":
        manifest = st.session_state.get("system_wide_readiness_manifest_20260618")
        if isinstance(manifest, dict) and not bool(manifest.get("ready")) and st.session_state.get("settings_run_complete_20260617"):
            missing = [name for name, item in (manifest.get("components") or {}).items() if isinstance(item, dict) and not item.get("ready")]
            if missing:
                st.warning(
                    f"Published generation {manifest.get('calculation_generation', '-')} is available with visible component errors: "
                    + ", ".join(missing[:6])
                    + ("…" if len(missing) > 6 else "")
                    + ". Open Settings → Errors / Fix Fast for exact details."
                )

    if page == "Settings":
        _render_settings()
    elif page == "Lunch":
        _render_lunch({}, subpage)
    elif page == "Field 4 to 9":
        from tabs.field456789_page_20260626 import show as _show_field456789
        _show_field456789({**dict(runtime_context or {}), "active_page": "Dinner"})
    elif page == "Field 456+789":
        from tabs.field456789_page_20260626 import show as _show_alias_combined
        _show_alias_combined({**dict(runtime_context or {}), "active_page": "Dinner"})
    elif page == "Field 456":
        from tabs.field456_page_20260626 import show as _show_field456
        _show_field456(runtime_context)
    elif page == "Field 789":
        from tabs.field789_page_20260626 import show as _show_field789
        _show_field789(runtime_context)
    elif page == "Dinner":
        _render_dinner({}, subpage)
    elif page == "AI Assistant":
        from pages.ai_assistant import show as _show_independent_ai
        _show_independent_ai(runtime_context)
    elif page == "Morning":
        _render_morning()
    elif page == "Research":
        _render_research(subpage)
    elif page == "Other":
        _render_other()
    else:
        _render_settings()
